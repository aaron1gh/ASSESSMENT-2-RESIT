﻿public class GameMap
{
    public Room StartRoom { get; private set; }

    public GameMap()
    {
        Room room1 = new Room("A damp dungeon corridor", new Goblin());
        Room room2 = new Room("A torch-lit chamber", new Dragon());

        room1.NextRoom = room2;
        StartRoom = room1;
    }
}