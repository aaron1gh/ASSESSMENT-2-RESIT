﻿public abstract class Item : ICollectible
{
    public string Name { get; protected set; }
    public abstract void Use(Player player);
}

public class Potion : Item
{
    private int healAmount;

    public Potion(string name, int healAmount)
    {
        Name = name;
        this.healAmount = healAmount;
    }

    public override void Use(Player player)
    {
        player.TakeDamage(-healAmount); // Negative damage = healing
        Console.WriteLine($"{player.Name} heals for {healAmount} points.");
    }
}
