﻿public class Monster : Creature
{
    public int Damage { get; protected set; }

    public Monster(string name, int health, int damage) : base(name, health)
    {
        Damage = damage;
    }

    public override void Attack(Creature target)
    {
        Console.WriteLine($"{Name} attacks for {Damage} damage!");
        target.TakeDamage(Damage);
    }
}