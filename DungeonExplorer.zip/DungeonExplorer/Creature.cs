﻿public abstract class Creature
{
    public string Name { get; protected set; }
    public int Health { get; protected set; }

    public bool IsAlive => Health > 0;  // <-- Add this property

    protected Creature(string name, int health)
    {
        Name = name;
        Health = health;
    }

    public abstract void Attack(Creature target);

    public void TakeDamage(int amount)
    {
        Health -= amount;
        if (Health < 0) Health = 0;
    }
}