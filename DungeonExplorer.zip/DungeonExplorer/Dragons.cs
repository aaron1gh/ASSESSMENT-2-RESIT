﻿public class Dragon : Monster
{
    public Dragon() : base("Dragon", 100, 25) { }

    public override void Attack(Creature target)
    {
        Console.WriteLine("The dragon breathes fire!");
        target.TakeDamage(Damage + 10);
    }
}