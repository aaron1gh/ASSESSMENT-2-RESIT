﻿using System;
using System.Linq;

public class Player : Creature, IDamageable
{
    public Inventory Inventory { get; private set; }

    public Player(string name, int health) : base(name, health)
    {
        Inventory = new Inventory();
    }

    public override void Attack(Creature target)
    {
        Console.WriteLine($"{Name} attacks!");
        target.TakeDamage(10); // Example damage
    }

    public void UseItem(string itemName)
    {
        var item = Inventory.Items.FirstOrDefault(i => i.Name.Equals(itemName, StringComparison.OrdinalIgnoreCase));
        if (item == null)
        {
            Console.WriteLine($"You don't have an item named {itemName}.");
            return;
        }

        item.Use(this);
        Inventory.Items.Remove(item);
    }
}