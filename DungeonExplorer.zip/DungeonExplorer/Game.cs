﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Game
{
    private Player player;
    private Room currentRoom;

    public void Start()
    {
        Console.WriteLine("Enter your character's name:");
        string name = Console.ReadLine();
        player = new Player(name, 100);

        GameMap map = new GameMap();
        currentRoom = map.StartRoom;

        while (true)
        {
            Console.WriteLine($"\nCurrent Room: {currentRoom.Description}");
            if (currentRoom.Monster != null && currentRoom.Monster.IsAlive)
            {
                Console.WriteLine($"A wild {currentRoom.Monster.Name} appears!");
                Battle(currentRoom.Monster);
            }

            Console.WriteLine("Options: [move] [inventory] [use] [exit]");
            string input = Console.ReadLine().ToLower();

            switch (input)
            {
                case "move":
                    if (currentRoom.NextRoom != null)
                    {
                        currentRoom = currentRoom.NextRoom;
                    }
                    else
                    {
                        Console.WriteLine("There's nowhere else to go.");
                    }
                    break;
                case "inventory":
                    player.Inventory.ShowItems();
                    break;
                case "use":
                    Console.WriteLine("Enter item name to use:");
                    string itemName = Console.ReadLine();
                    player.UseItem(itemName);
                    break;
                case "exit":
                    Console.WriteLine("Thanks for playing!");
                    return;
                default:
                    Console.WriteLine("Invalid command.");
                    break;
            }
        }
    }

    private void Battle(Monster monster)
    {
        while (player.IsAlive && monster.IsAlive)
        {
            player.Attack(monster);
            if (!monster.IsAlive) break;

            monster.Attack(player);
        }

        if (!player.IsAlive)
        {
            Console.WriteLine("You have been defeated!");
            Environment.Exit(0);
        }

        Console.WriteLine($"You defeated the {monster.Name}!");
        player.Inventory.Add(new Potion("Health Potion", 20));
    }
}