﻿public interface IDamageable
{
    void TakeDamage(int amount);
}

public interface ICollectible
{
    void Use(Player player);
}