﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Inventory
{
    public List<Item> Items { get; private set; } = new List<Item>();

    public void Add(Item item)
    {
        Items.Add(item);
        Console.WriteLine($"{item.Name} added to inventory.");
    }

    public void ShowItems()
    {
        if (Items.Count == 0)
        {
            Console.WriteLine("Inventory is empty.");
            return;
        }

        Console.WriteLine("Inventory:");
        foreach (var item in Items)
        {
            Console.WriteLine($"- {item.Name}");
        }
    }
}