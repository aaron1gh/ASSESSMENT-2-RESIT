﻿public class Goblin : Monster
{
    public Goblin() : base("Goblin", 30, 10) { }

    public override void Attack(Creature target)
    {
        Console.WriteLine("The goblin attacks!");
        target.TakeDamage(Damage);
    }
}