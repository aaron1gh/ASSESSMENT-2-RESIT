﻿public class Room
{
    public string Description { get; private set; }
    public Monster Monster { get; private set; }
    public Room NextRoom { get; set; }

    public Room(string description, Monster monster)
    {
        Description = description;
        Monster = monster;
    }
}